# To install run each of these commands:
conda install -y -c anaconda numpy
conda install -y -c anaconda scipy
conda install -y -c anaconda matplotlib
conda install -y -c anaconda jupyter
conda install -y -c https://conda.anaconda.org/kne pybox2d
conda install -y -c cogsci pygame

